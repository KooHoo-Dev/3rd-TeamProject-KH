#ifndef ALLIN1SPRITESHADERSRP_SHADERFEATURES
#define ALLIN1SPRITESHADERSRP_SHADERFEATURES

#pragma shader_feature_local GLOW_ON
#pragma shader_feature_local FADE_ON
#pragma shader_feature_local OUTBASE_ON
#pragma shader_feature_local ONLYOUTLINE_ON
#pragma shader_feature_local GRADIENT_ON
#pragma shader_feature_local GRADIENT2COL_ON
#pragma shader_feature_local RADIALGRADIENT_ON
#pragma shader_feature_local COLORSWAP_ON
#pragma shader_feature_local HSV_ON
#pragma shader_feature_local CHANGECOLOR_ON
#pragma shader_feature_local CHANGECOLOR2_ON
#pragma shader_feature_local CHANGECOLOR3_ON
#pragma shader_feature_local COLORRAMP_ON
#pragma shader_feature_local GRADIENTCOLORRAMP_ON
#pragma shader_feature_local HITEFFECT_ON
#pragma shader_feature_local NEGATIVE_ON
#pragma shader_feature_local PIXELATE_ON
#pragma shader_feature_local GREYSCALE_ON
#pragma shader_feature_local POSTERIZE_ON
#pragma shader_feature_local BLUR_ON
#pragma shader_feature_local MOTIONBLUR_ON
#pragma shader_feature_local GHOST_ON
#pragma shader_feature_local ALPHAOUTLINE_ON
#pragma shader_feature_local INNEROUTLINE_ON
#pragma shader_feature_local ONLYINNEROUTLINE_ON
#pragma shader_feature_local HOLOGRAM_ON
#pragma shader_feature_local CHROMABERR_ON
#pragma shader_feature_local GLITCH_ON
#pragma shader_feature_local FLICKER_ON
#pragma shader_feature_local SHADOW_ON
#pragma shader_feature_local SHINE_ON
#pragma shader_feature_local CONTRAST_ON
#pragma shader_feature_local OVERLAY_ON
#pragma shader_feature_local OVERLAYMULT_ON
#pragma shader_feature_local ALPHACUTOFF_ON
#pragma shader_feature_local ALPHAROUND_ON
#pragma shader_feature_local DOODLE_ON
#pragma shader_feature_local WIND_ON
#pragma shader_feature_local WAVEUV_ON
#pragma shader_feature_local ROUNDWAVEUV_ON
#pragma shader_feature_local RECTSIZE_ON
#pragma shader_feature_local OFFSETUV_ON
#pragma shader_feature_local CLIPPING_ON
#pragma shader_feature_local RADIALCLIPPING_ON
#pragma shader_feature_local TEXTURESCROLL_ON
#pragma shader_feature_local ZOOMUV_ON
#pragma shader_feature_local DISTORT_ON
#pragma shader_feature_local WARP_ON
#pragma shader_feature_local TWISTUV_ON
#pragma shader_feature_local ROTATEUV_ON
#pragma shader_feature_local POLARUV_ON
#pragma shader_feature_local FISHEYE_ON
#pragma shader_feature_local PINCH_ON
#pragma shader_feature_local SHAKEUV_ON

#pragma shader_feature_local GLOWTEX_ON
#pragma shader_feature_local OUTTEX_ON
#pragma shader_feature_local OUTDIST_ON
#pragma shader_feature_local OUTBASE8DIR_ON
#pragma shader_feature_local OUTBASEPIXELPERF_ON
#pragma shader_feature_local COLORRAMPOUTLINE_ON
#pragma shader_feature_local GREYSCALEOUTLINE_ON
#pragma shader_feature_local POSTERIZEOUTLINE_ON
#pragma shader_feature_local BLURISHD_ON
#pragma shader_feature_local MANUALWIND_ON
#pragma shader_feature ATLAS_ON
#pragma shader_feature PREMULTIPLYALPHA_ON

#pragma shader_feature BILBOARD_ON
#pragma shader_feature BILBOARDY_ON
#pragma shader_feature FOG_ON

#endif